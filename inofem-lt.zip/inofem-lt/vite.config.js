export default {
  root: '.',
};
